package sixqaq;

import cn.nukkit.Player;
import cn.nukkit.command.CommandSender;
import cn.nukkit.plugin.PluginBase;


import sixqaq.command.*;
import sixqaq.event.formResponseEvent;
import sixqaq.event.joinListener;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.*;

public class Money extends PluginBase {
    static Connection conn = null;
    public static Statement stmt = null;
    public static Money instance;

    @Override
    public void onLoad() {
        getLogger().info("Money");
        try {
            this.getDataFolder().mkdirs();
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:plugins/Money/money.db");//方法一：用sqlite
            //conn = Sqlite.getConnection("plugins/Money/money.db");//方法二：调用sixqaq.Sqlite的
            stmt = conn.createStatement();
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS money(" +
                    "name VARCHAR(100) PRIMARY KEY," +
                    "money INTEGER NOT NULL," +
                    "CONSTRAINT chk_money CHECK(money >= 0)" +
                    ")");
        } catch (Exception e) {
            Money.error(e);
        }
    }

    //注册指令、事件
    @Override
    public void onEnable() {
        instance = this;
        this.saveDefaultConfig();
        getServer().getCommandMap().register("Money", new MoneyAdd());
        getServer().getCommandMap().register("Money", new MoneyReduce());
        getServer().getCommandMap().register("Money", new MoneySet());
        getServer().getCommandMap().register("Money", new MoneyGet());
        getServer().getCommandMap().register("Money", new MoneyTop());
        getServer().getCommandMap().register("Money", new MoneyPay());
        getServer().getCommandMap().register("Money", new MoneyTrans());
        getServer().getCommandMap().register("Money", new MoneyHelp());
        getServer().getCommandMap().register("Money", new MoneyUi());
        getServer().getPluginManager().registerEvents(new joinListener(), this);
        getServer().getPluginManager().registerEvents(new formResponseEvent(), this);
    }

    //插件卸载时关闭数据库
    @Override
    public void onDisable() {
        try {
            conn.close();
        } catch (Exception e) {
            Money.error(e);
        }
    }
    //增加数据库中玩家余额
    public static boolean add(String name, Integer added) {
        try {
            stmt.executeUpdate("UPDATE money SET money = money + %d WHERE name = '%s'".formatted(added, name));
        } catch (Exception e) {
            Money.error(e);
            return false;
        }
        return true;
    }
//减少数据库中玩家余额
    public static boolean reduce(String name, Integer reduced) {
        try {
            stmt.executeUpdate("UPDATE money SET money = money - %d WHERE name = '%s'".formatted(reduced, name));
        } catch (Exception e) {
            Money.error(e);
            return false;
        }
        return true;
    }
//从数据库读取玩家余额
    public static Integer get(String name) {
        try {
            ResultSet rs = stmt.executeQuery("SELECT money FROM money WHERE name = '%s'".formatted(name));
            if (rs.next()) {
                return rs.getInt("money");
            }
        } catch (Exception e) {
            Money.error(e);
        }
        return -1;
    }

    //设置数据库中玩家的余额
    public static boolean set(String name, Integer value) {
        try {
            stmt.executeUpdate("UPDATE money SET money = %s WHERE name = '%s'".formatted(value, name));
        } catch (Exception e) {
            Money.error(e);
            return false;
        }
        return true;
    }

    public static boolean trans(String from, String to, Integer value) {

        if (!reduce(from, value)) {//尝试扣钱，扣钱失败则回退，并返回失败
            add(to, value);
            return false;
        }
        if (!add(from, value)) {//尝试加钱，加钱失败则回退，并返回失败
            add(to, value);
            return false;
        }
        return true;
    }

    public static Map<String, Integer> top(int num) {
        try {//选取降序排列前num条记录
            ResultSet rs = stmt.executeQuery("SELECT * FROM money ORDER BY money DESC LIMIT %d".formatted(num));
            Map<String, Integer> moneyTop = new LinkedHashMap<>();
            while (rs.next()) {
                moneyTop.put(rs.getString("name"), rs.getInt("money"));
            }
            return moneyTop;
        } catch (Exception e) {
            error(e);
            return null;
        }
    }

    public static void error(Exception e) {
        System.out.println(e.getClass().getName() + ":" + e.getMessage());
    }

    //用来解析选择器，将@s替换为命令使用者自己，@a替换为全体玩家名。
    public static List<String> parseSelector(String sender_name, String selector) {
        List<String> players = new ArrayList<>();
        if (selector.equals("@s")) {
            players.add(sender_name);
        } else if (selector.equals("@a")) {
            for (Player pl : getInstance().getServer().getOnlinePlayers().values()) {
                players.add(pl.getName());
            }

        } else
            players.add(selector);
        return players;
    }

    public static Money getInstance() {
        return instance;
    }

    public static List<String> getOnlinePlayerNames() {
        List<String> onlinePlayers = new ArrayList<>();
        Money.getInstance().getServer().getOnlinePlayers().values().forEach(player1 -> {
            onlinePlayers.add(player1.getName());
        });
        return onlinePlayers;
    }

    public static List<String> getOnlinePlayerNames(List<String> appended) {
        Money.getInstance().getServer().getOnlinePlayers().values().forEach(player1 -> {
            appended.add(player1.getName());
        });
        return appended;
    }

    public static List<String> getOfflinePlayerNames() {
        List<String> offlinePlayerNames = new ArrayList<>();
        List<String> onlinePlayerNames = Money.getOnlinePlayerNames();
        try {
            String name;
            ResultSet rs = stmt.executeQuery("SELECT name FROM money;");
            while (rs.next()) {
                name = rs.getString("name");
                if (!onlinePlayerNames.contains(name))
                    offlinePlayerNames.add(name);
            }
        } catch (Exception e) {
            Money.error(e);
        }
        return offlinePlayerNames;
    }

    public static List<String> getOfflinePlayerNames(List<String> appended) {
        List<String> onlinePlayerNames = Money.getOnlinePlayerNames();
        try {
            String name;
            ResultSet rs = stmt.executeQuery("SELECT name FROM money;");
            while (rs.next()) {
                name = rs.getString("name");
                if (!onlinePlayerNames.contains(name))
                    appended.add(name);
            }
        } catch (Exception e) {
            Money.error(e);
        }
        return appended;
    }

}
