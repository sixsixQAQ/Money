package sixqaq.command;

import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;
import sixqaq.Money;

import java.util.Map;

public class MoneyTop extends Command {//展示前10名榜单
    public MoneyTop() {
        super("moneytop", "§6金钱排行榜", "/moneytop", new String[]{"mtop"});
        commandParameters.clear();
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!sender.hasPermission("money.command.moneytop")) {//鉴权基操，权限在plugin.yml的permissons
            sender.sendMessage("§b你没有权限使用该指令.");
            return false;
        }
        if (args.length != 0)
            return false;
        sender.sendMessage(topText(10));//前10名够了。
        return true;
    }

    public static String topText(int topNum) {//拼接topnumm名字符串并返回。
        Map<String, Integer> moneyTop = Money.top(topNum);
        String text = "§6金钱前%d榜\n".formatted(topNum);
        if (moneyTop == null)
            return "数据库未知错误";
        for (Map.Entry<String, Integer> entry : moneyTop.entrySet()) {
            text += "§b%-20s§6%d\n".formatted(entry.getKey(), entry.getValue());
        }
        return text;
    }
}
