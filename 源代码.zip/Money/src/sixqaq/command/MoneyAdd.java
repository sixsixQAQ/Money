package sixqaq.command;

import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;
import cn.nukkit.command.data.CommandParamType;
import cn.nukkit.command.data.CommandParameter;

import sixqaq.Money;

import java.util.List;

public class MoneyAdd extends Command {//加钱(OP)
    public MoneyAdd() {
        super("moneyadd", "§6增加钱", "/moneyadd <player> <amount>", new String[]{"ma"});
        commandParameters.clear();
        commandParameters.put("default", new CommandParameter[]{
                CommandParameter.newType("player", false, CommandParamType.TARGET),
                CommandParameter.newType("amount", false, CommandParamType.INT)
        });
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!sender.hasPermission("money.command.moneyadd")) {//鉴权基操，权限在plugin.yml的permissons
            sender.sendMessage("§b你没有权限使用该指令.");
            return false;
        }
        if (args.length != 2) return false;
        try {
            String targets_selector = args[0];
            Integer amount = Integer.valueOf(args[1]);

            Money money = new Money();
            List<String> targets = Money.parseSelector(sender.getName(), targets_selector);//解析选择器
            for (String target : targets) {
                if (Money.add(target, amount))
                    sender.sendMessage("§b%s的钱增加了%d\n".formatted(target, amount));
                else
                    sender.sendMessage("§b%s金额溢出，增加失败\n".formatted(target));
            }

        } catch (Exception e) {
            sender.sendMessage("§b非法数值\n");
            Money.error(e);
            return false;
        }
        return true;
    }
}
