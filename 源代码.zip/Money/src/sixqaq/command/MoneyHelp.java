package sixqaq.command;

import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;

public class MoneyHelp extends Command {
    public MoneyHelp() {
        super("moneyhelp", "§6money插件使用帮助", "/moneyhelp", new String[]{"mh"});
        commandParameters.clear();
    }

    public static String helpText(boolean isOp) {//返回帮助手册文本，区分OP
        if (isOp)
            return "§bmoney帮助手册:\n" +
                    "§6[]内参数为可选，<>内参数为必选。\n" +
                    "指令可缩写,如/moneyset == /ms\n" +
                    "§a/<moneyui/mui/mu> §6- 打开money界面\n" +
                    "§a/<moneyget/money/mg> [玩家] §6- 查看钱(缺省为自己)\n" +
                    "§a/<moneypay/mp> <玩家> <数额> §6- 转账给玩家\n" +
                    "§a/<moneytop/mtop> §6- 查看money排行榜\n" +


                    "§a/<moneyset/ms> <玩家> <数额> §6- 设置钱\n" +
                    "§a/<moneytrans/mt> <转出者> <转入者> <数额> §6- 转移玩家钱\n" +
                    "§a/<moneyadd/ma> <玩家> <数额> §6- 增加玩家钱\n" +
                    "§a/<moneyreduce/mr> <玩家> <数额> §6- 减少玩家钱";
        else
            return "§bmoney帮助手册:\n" +
                    "§6[]内参数为可选，<>内参数为必选。\n" +
                    "指令可缩写,如/moneyset == /ms\n" +

                    "§a/<moneyui/mui/mu> §6- 打开money界面\n" +
                    "§a/<moneyget/money/mg> [玩家] §6- 查看钱(缺省为自己)\n" +
                    "§a/<moneypay/mp> <玩家> <数额> §6- 转账给玩家\n" +
                    "§a/<moneytop/mtop> §6- 查看money排行榜\n";
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!sender.hasPermission("money.command.moneyhelp")) {//鉴权基操，权限在plugin.yml的permissons
            sender.sendMessage("§b你没有权限使用该指令.");
            return false;
        }

        if (args.length == 0) {
            if (sender.isOp())
                sender.sendMessage(helpText(true));
            else sender.sendMessage(helpText(false));
        } else if (args.length == 1) {

        } else return false;
        return true;
    }
}
