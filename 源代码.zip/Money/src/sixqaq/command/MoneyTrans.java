package sixqaq.command;

import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;
import cn.nukkit.command.data.CommandParamType;
import cn.nukkit.command.data.CommandParameter;
import sixqaq.Money;

public class MoneyTrans extends Command {//转移钱(OP)
    public MoneyTrans() {
        super("moneytrans", "§6转移钱", "/moneytrans <player_from> <player_to> <amount>",
                new String[]{"mt"});
        commandParameters.clear();
        commandParameters.put("default", new CommandParameter[]{
                CommandParameter.newType("player_from", false, CommandParamType.TARGET),
                CommandParameter.newType("player_to", false, CommandParamType.TARGET),
                CommandParameter.newType("amount", false, CommandParamType.INT)
        });
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!sender.hasPermission("money.command.moneytrans")) {//鉴权基操，权限在plugin.yml的permissons
            sender.sendMessage("§b你没有权限使用该指令.");
            return false;
        }

        if (args.length != 3)
            return false;
        try {
            String from = args[0];
            String to = args[1];
            if (from.equals("@s")) from = sender.getName();//这里大可不必用Money.parseSelector，现转
            if (to.equals("@s")) to = sender.getName();

            Integer amount = Integer.valueOf(args[2]);
            if (Money.trans(from, to, amount))
                sender.sendMessage("§b从玩家%s转移了%d到玩家%s".formatted(from, amount, to));
            else sender.sendMessage("§b余额不足或溢出上限，转账失败！");
        } catch (Exception e) {
            sender.sendMessage("§b非法数值\n");
            Money.error(e);
            return false;
        }
        return true;
    }
}
