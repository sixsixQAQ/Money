package sixqaq.command;

import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;
import cn.nukkit.command.data.CommandParamType;
import cn.nukkit.command.data.CommandParameter;
import sixqaq.Money;

public class MoneyPay extends Command {//转账
    public MoneyPay() {
        super("moneypay", "§6给钱", "/moneypay <player> <amount>", new String[]{"mp", "pay"});
        this.commandParameters.clear();
        this.commandParameters.put("default", new CommandParameter[]{
                CommandParameter.newType("player", false, CommandParamType.TARGET),
                CommandParameter.newType("amount", false, CommandParamType.INT)
        });
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!sender.hasPermission("money.command.moneypay")) {//鉴权基操，权限在plugin.yml的permissons
            sender.sendMessage("§b你没有权限使用该指令.");
            return false;
        }
        if (args.length != 2)
            return false;
        try {
            String from = sender.getName();
            String to = args[0];

            if (from.equals("@s")) from = sender.getName();
            if (to.equals("@s")) to = sender.getName();

            Integer amount = Integer.valueOf(args[1]);
            if (amount < 0) {
                sender.sendMessage("§b付款金额不能为负");
                return false;
            }
            if (Money.trans(from, to, amount)) {
                sender.sendMessage("§b给了%s金钱%s".formatted(to, amount));
            } else {
                sender.sendMessage("§b余额不足,给钱失败");
            }
        } catch (Exception e) {
            sender.sendMessage("§b非法数值\n");
            Money.error(e);
            return false;
        }
        return true;
    }
}
