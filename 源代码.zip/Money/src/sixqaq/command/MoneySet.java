package sixqaq.command;

import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;
import cn.nukkit.command.data.CommandParamType;
import cn.nukkit.command.data.CommandParameter;
import sixqaq.Money;

import java.util.List;

public class MoneySet extends Command {//设置钱(OP)
    public MoneySet() {
        super("moneyset", "§6设置钱", "/moneyset <player> <amount>", new String[]{"ms"});
        commandParameters.clear();
        commandParameters.put("default", new CommandParameter[]{
                CommandParameter.newType("player", false, CommandParamType.TARGET),
                CommandParameter.newType("amount", false, CommandParamType.INT)
        });
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!sender.hasPermission("money.command.moneyset")) {//鉴权基操，权限在plugin.yml的permissons
            sender.sendMessage("§b你没有权限使用该指令.");
            return false;
        }
        if (args.length != 2) return false;
        try {
            String targets_selector = args[0];
            Integer amount = Integer.valueOf(args[1]);

            Money money = new Money();
            List<String> targets = Money.parseSelector(sender.getName(), targets_selector);
            for (String target : targets) {
                if (Money.set(target, amount))
                    sender.sendMessage("§b%s的钱被设置为%d\n".formatted(target, amount));
                else
                    sender.sendMessage("§b%s金额溢出，设定失败\n".formatted(target));
            }
        } catch (Exception e) {
            sender.sendMessage("§b非法数值\n");
            Money.error(e);
            return false;
        }
        return true;
    }
}
