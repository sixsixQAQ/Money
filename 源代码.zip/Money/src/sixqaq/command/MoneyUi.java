package sixqaq.command;

import cn.nukkit.Player;
import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;

import sixqaq.ui.Ui;

public class MoneyUi extends Command {//显示Money Ui的命令
    public MoneyUi() {
        super("moneyui", "§6money的UI", "/moneyui", new String[]{"mui", "mu"});
        commandParameters.clear();
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!sender.hasPermission("money.command.moneyui")) {//鉴权基操，权限在plugin.yml的permissons
            sender.sendMessage("§b你没有权限使用该指令.");
            return false;
        }
        if (args.length != 0 || !sender.isPlayer())//注意判断得是玩家，控制台不能用表单。
            return false;
        Ui.showCmdMenu((Player) sender);//发送总表单
        return true;
    }
}
