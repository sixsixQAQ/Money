package sixqaq.command;

import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;
import cn.nukkit.command.data.CommandParamType;
import cn.nukkit.command.data.CommandParameter;
import sixqaq.Money;

import java.util.List;

public class MoneyGet extends Command {//看钱


    public MoneyGet() {
        super("moneyget", "§6查看钱", "/moneyget [player]", new String[]{"mg", "money"});
        commandParameters.clear();
        commandParameters.put("default", new CommandParameter[]{
                CommandParameter.newType("player", true, CommandParamType.TARGET)
        });
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!sender.hasPermission("money.command.moneyget")) {//鉴权基操，权限在plugin.yml的permissons
            sender.sendMessage("§b你没有权限使用该指令.");
            return false;
        }

        String targets_selector;
        if (args.length == 0)
            targets_selector = sender.getName();
        else if (args.length == 1)
            targets_selector = args[0];
        else return false;

        try {
            Integer amount;
            Money money = new Money();
            List<String> targets = Money.parseSelector(sender.getName(), targets_selector);
            for (String target : targets) {
                amount = Money.get(target);
                if (amount == -1)
                    sender.sendMessage("§b未查询到玩家%s的信息".formatted(target));
                else
                    sender.sendMessage("§b玩家%s的余额为%d".formatted(target, amount));
            }
        } catch (Exception e) {
            Money.error(e);
            return false;
        }
        return true;
    }
}
