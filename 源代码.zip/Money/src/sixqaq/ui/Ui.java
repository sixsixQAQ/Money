package sixqaq.ui;

import cn.nukkit.Player;
import cn.nukkit.form.element.*;
import cn.nukkit.form.window.FormWindowCustom;
import cn.nukkit.form.window.FormWindowSimple;
import sixqaq.Money;
import sixqaq.command.MoneyHelp;
import sixqaq.command.MoneyTop;


import java.util.*;


public class Ui {
    public static final int cmdMenu = 1000;
    public static final int moneyAddMenu = 1001;
    public static final int moneyReduceMenu = 1002;
    public static final int moneyPayMenu = 1003;
    public static final int moneySetMenu = 1004;
    public static final int moneyHelpMenu = 1005;
    public static final int moneyTopMenu = 1006;
    public static final int moneyTransMenu = 1007;
    public static final Map<String, String> buttonTextMap = new HashMap<>() {
        {
            put("moneypay", "转账");
            put("moneytop", "排行榜");
            put("moneyhelp", "帮助手册");
            put("moneyadd", "增加钱");
            put("moneyreduce", "减少钱");
            put("moneyset", "设置钱");
            put("moneytrans", "转移钱");
        }
    };
    public static final List<String> buttonTextList = Arrays.asList(//纯粹不想用上面的buttontextMap，少写几个单词，写数字。
            "转账",
            "排行榜",
            "帮助手册",
            "增加钱",
            "减少钱",
            "设置钱",
            "转移钱");
    public static final List<ElementButton> simpleButtonList = Arrays.asList(
            new ElementButton(buttonTextList.get(0)),
            new ElementButton(buttonTextList.get(1))
    );
    public static final List<ElementButton> opButtonList = Arrays.asList(
            new ElementButton(buttonTextList.get(2)),
            new ElementButton(buttonTextList.get(3)),
            new ElementButton(buttonTextList.get(4)),
            new ElementButton(buttonTextList.get(5)),
            new ElementButton(buttonTextList.get(6))
    );


    //add、set、reduce、pay这四条命令对应的表单具有相同格式/排版（它们的操作数也是相同类型），把它们统一化。
    public static void moneySameMenu(Player player, String buttonTextKey,
                                     int menuId, boolean is_selector_all_included) {
        FormWindowCustom form = new FormWindowCustom(buttonTextMap.get(buttonTextKey));
        form.addElement(new ElementLabel("§b选择玩家："));
        form.addElement(new ElementDropdown("§6在线玩家", dropDownPlayers(true)));
        form.addElement(new ElementDropdown("§6Money库中离线玩家", dropDownPlayers(false)));
        if (is_selector_all_included)
            form.addElement(new ElementDropdown("§6选择器", Arrays.asList("", "@s", "@a")));
        else
            form.addElement(new ElementDropdown("§6选择器", Arrays.asList("", "@s")));
        form.addElement(new ElementInput("§e金额"));
        player.showFormWindow(form, menuId);
    }

    public static void moneyAdd(Player player) {
        moneySameMenu(player, "moneyadd", moneyAddMenu, true);
    }

    public static void moneyHelp(Player player) {
        String helpText = MoneyHelp.helpText(player.isOp());
        FormWindowSimple form = new FormWindowSimple(buttonTextMap.get("moneyhelp"), helpText);
        player.showFormWindow(form, moneyHelpMenu);
    }

    public static void moneyTop(Player player) {
        String topText = MoneyTop.topText(10);
        FormWindowSimple form = new FormWindowSimple(buttonTextMap.get("moneyhelp"), topText);
        player.showFormWindow(form, moneyTopMenu);
    }

    public static void moneyReduce(Player player) {
        moneySameMenu(player, "moneyreduce", moneyReduceMenu, true);
    }

    public static void moneySet(Player player) {
        moneySameMenu(player, "moneyset", moneySetMenu, true);
    }

    public static void moneyTrans(Player player) {
        FormWindowCustom form = new FormWindowCustom(buttonTextMap.get("moneytrans"));
        form.addElement(new ElementLabel("§b选择转出者："));
        form.addElement(new ElementDropdown("§6在线玩家", dropDownPlayers(true)));
        form.addElement(new ElementDropdown("§6Money库中离线玩家", dropDownPlayers(false)));
        form.addElement(new ElementDropdown("§6选择器", Arrays.asList("", "@s")));
        form.addElement(new ElementLabel("§b选择转入者："));
        form.addElement(new ElementDropdown("§6在线玩家", dropDownPlayers(true)));
        form.addElement(new ElementDropdown("§6Money库中离线玩家", dropDownPlayers(false)));
        form.addElement(new ElementDropdown("§6选择器", Arrays.asList("", "@s")));
        form.addElement(new ElementInput("§e设置的金额"));
        player.showFormWindow(form, moneyTransMenu);
    }

    public static void moneyPay(Player player) {
        moneySameMenu(player, "moneypay", moneyPayMenu, false);
    }

    public static void showCmdMenu(Player player) {
        FormWindowSimple form = new FormWindowSimple("Money系统", "§b我的余额：§e%d".formatted(Money.get(player.getName())));
        for (ElementButton button : simpleButtonList) {
            form.addButton(button);
        }
        if (player.isOp()) {
            for (ElementButton button : opButtonList) {
                form.addButton(button);
            }
        }
        player.showFormWindow(form, cmdMenu);
    }

    public static List<String> dropDownPlayers(boolean isOnline) {
        if (isOnline) {
            return Money.getOnlinePlayerNames(new ArrayList<String>() {
                {
                    add("");
                }
            });
        } else
            return Money.getOfflinePlayerNames(new ArrayList<String>() {
                {
                    add("");
                }
            });
    }
}
