package sixqaq.event;

import cn.nukkit.Player;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.Listener;
import cn.nukkit.event.player.PlayerFormRespondedEvent;
import cn.nukkit.form.response.FormResponseCustom;
import cn.nukkit.form.response.FormResponseSimple;
import sixqaq.command.*;
import sixqaq.ui.Ui;


public class formResponseEvent implements Listener {
    @EventHandler
    public void onFormResponse(PlayerFormRespondedEvent e) {
        Player player = e.getPlayer();
        int id = e.getFormID();
        if (id == Ui.cmdMenu) {//当有表单事件时，首先判断是否为总表单。
            FormResponseSimple response = (FormResponseSimple) e.getResponse();
            if (response == null)
                return;
            String clickedButtonText = response.getClickedButton().getText();
            switch (clickedButtonText) {
                case "转账" -> Ui.moneyPay(player);
                case "排行榜" -> Ui.moneyTop(player);
                case "设置钱" -> Ui.moneySet(player);
                case "增加钱" -> Ui.moneyAdd(player);
                case "减少钱" -> Ui.moneyReduce(player);
                case "转移钱" -> Ui.moneyTrans(player);
                case "帮助手册" -> Ui.moneyHelp(player);
            }
            return;
        }
        //否则，不是总表单，是下面的子表单。
        if (id == Ui.moneyHelpMenu || id == Ui.moneyTopMenu)//这两个子表单只用来显示内容，只有关闭按钮，不必处理，返回即可。
            return;
        FormResponseCustom response = (FormResponseCustom) e.getResponse();
        if (response == null)//当点击任何表单的关闭按钮时，也会触发表单事件，但是为null，若不判空，下面的代码尝试获取表单内容就会报错。
            return;
        //这是获取 moneySameMenu的所有步骤；也是获取特殊表单moneyTransMenu的部分步骤。（看不懂请画一下表单布局）
        String targets_selector = response.getDropdownResponse(1).getElementContent();
        if (targets_selector.equals(""))
            targets_selector = response.getDropdownResponse(2).getElementContent();
        if (targets_selector.equals(""))
            targets_selector = response.getDropdownResponse(3).getElementContent();
        String amount = response.getInputResponse(4);

        switch (id) {
            case Ui.moneyAddMenu -> {
                MoneyAdd cmd = new MoneyAdd();
                cmd.execute(player, "moneyadd", new String[]{targets_selector, amount});
            }
            case Ui.moneyReduceMenu -> {
                MoneyReduce cmd = new MoneyReduce();
                cmd.execute(player, "moneyreduce", new String[]{targets_selector, amount});
            }
            case Ui.moneySetMenu -> {
                MoneySet cmd = new MoneySet();
                cmd.execute(player, "moneyset", new String[]{targets_selector, amount});
            }
            case Ui.moneyPayMenu -> {
                MoneyPay cmd = new MoneyPay();
                cmd.execute(player, "moneypay", new String[]{targets_selector, amount});
            }
            case Ui.moneyTransMenu -> {
                String targets_selector_2 = response.getDropdownResponse(5).getElementContent();
                if (targets_selector_2.equals(""))
                    targets_selector_2 = response.getDropdownResponse(6).getElementContent();
                if (targets_selector_2.equals(""))
                    targets_selector_2 = response.getDropdownResponse(7).getElementContent();
                MoneyTrans cmd = new MoneyTrans();
                String amount_2 = response.getInputResponse(8);//注意不能用上面的amount
                cmd.execute(player, "moneytrans", new String[]{targets_selector, targets_selector_2, amount_2});
            }
        }
    }

}
