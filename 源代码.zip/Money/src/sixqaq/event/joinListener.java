package sixqaq.event;

import cn.nukkit.event.EventHandler;
import cn.nukkit.event.Listener;
import cn.nukkit.event.player.PlayerJoinEvent;
import sixqaq.Money;

public class joinListener implements Listener {
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        try {
            String target = e.getPlayer().getName();
            if (Money.get(target) == -1)//玩家第一次加入，会将其加入Money数据库，并设定余额1000。
                Money.stmt.executeUpdate("INSERT INTO money(name, money) VALUES('%s', %d)".formatted(target, 1000));
        } catch (Exception exception) {
            Money.error(exception);
        }
    }
}
