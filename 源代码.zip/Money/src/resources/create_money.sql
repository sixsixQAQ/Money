CREATE TABLE IF NOT EXISTS money{
name    VARCHAR(100)    PRIMARY KEY,
money   INTEGER         NOT NULL,
CONSTRAINT chk_money CHECK(money >=0)
}